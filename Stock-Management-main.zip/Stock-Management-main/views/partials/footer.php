<footer class="footer">
	<div class="footer-content justify-content-between">
		<p class="m-b-0">Yvana Tannous\Saiid Hanna\Charbel Karaki - Stock Management</p>
		<span>
			<a href="" class="text-gray m-r-15"></a>
			<a href="" class="text-gray"></a>
		</span>
	</div>
</footer>
