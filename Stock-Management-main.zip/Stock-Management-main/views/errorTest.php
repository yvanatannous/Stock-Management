<?php include('layouts/boilerplate.php')?>
<div class="row">
    <div class="col-6 offset-3">
        <div class="alert alert-danger" role="alert">
            <h4 class="alert-heading"></h4>
        </div> 
    </div>
</div>